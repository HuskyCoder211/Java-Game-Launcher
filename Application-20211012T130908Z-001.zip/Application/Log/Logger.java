package Application.Log;

public class Logger {
  public Logger() {
    
  }
  
  public static void log(String data) {
    System.out.println(data);
  }
}
